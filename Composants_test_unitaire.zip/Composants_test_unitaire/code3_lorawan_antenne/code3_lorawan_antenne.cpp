#include "code3_lorawan_antenne.h"

int readTemperature(DHT11 dht11) {
    // Lit la température via la fonction fournie par la librairie DHT11
    int temperature = dht11.readTemperature();
    return temperature;
}

int readHumidity(DHT11 dht11) {
    // Lit l'humidité via la fonction fournie par la librairie DHT11
    int humidity = dht11.readHumidity();
    return humidity;
}
