#ifndef TEMPERATURE_READER_H
#define TEMPERATURE_READER_H

#include <DHT11.h>

// Lit la température (en °C) depuis le DHT11
int readTemperature(DHT11 dht11);

// Lit l'humidité (en %) depuis le DHT11
int readHumidity(DHT11 dht11);

#endif
