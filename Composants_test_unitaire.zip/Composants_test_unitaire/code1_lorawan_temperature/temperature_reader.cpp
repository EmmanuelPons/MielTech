#include "temperature_reader.h"

int readTemperature(DHT11 dht11) {
    int temperature = dht11.readTemperature();
    return temperature;
}
