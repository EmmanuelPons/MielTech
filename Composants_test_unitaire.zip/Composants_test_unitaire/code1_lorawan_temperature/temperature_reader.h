#ifndef TEMPERATURE_READER_H
#define TEMPERATURE_READER_H

#include <DHT11.h>

int readTemperature(DHT11 dht11);

#endif
